# app.py
import cv2
from flask import Flask, render_template, Response
from cvzone.PoseModule import PoseDetector

app = Flask(__name__)
cap = cv2.VideoCapture(0)
detector = PoseDetector()
tshirt_img = cv2.imread(r"C:\Users\mirut\Downloads\pythonProject\pythonProject\Resources\Shirts\1.png", cv2.IMREAD_UNCHANGED)

def generate_frames():
    while True:
        success, img = cap.read()
        if not success:
            break

        try:
            img = detector.findPose(img)
        except Exception as e:
            print(f"Error detecting pose: {e}")
            continue

        lmList, _ = detector.findPosition(img, bboxWithHands=False, draw=True)

        if lmList:
            lm11 = lmList[11][1:3]
            lm12 = lmList[12][1:3]

            try:
                width_of_tshirt = int((lm11[0] - lm12[0]) * 1.5)
                height_of_tshirt = int(width_of_tshirt * 1.5)
                tshirt_resized = cv2.resize(tshirt_img, (width_of_tshirt, height_of_tshirt))
                current_scale = (lm11[0] - lm12[0]) / 190
                offset = (int(44 * current_scale), int(48 * current_scale))
                alpha_channel = tshirt_resized[:, :, 3]
                resized_alpha = cv2.resize(alpha_channel, (width_of_tshirt, height_of_tshirt))
                mask = cv2.merge([resized_alpha] * 3)
                img[lm12[1] - offset[1]:lm12[1] - offset[1] + height_of_tshirt,
                    lm12[0] - offset[0]:lm12[0] - offset[0] + width_of_tshirt, :] = \
                    img[lm12[1] - offset[1]:lm12[1] - offset[1] + height_of_tshirt,
                        lm12[0] - offset[0]:lm12[0] - offset[0] + width_of_tshirt, :] * (1 - mask / 255.0) + \
                    tshirt_resized[:, :, :3] * (mask / 255.0)

            except Exception as e:
                print(f"Error overlaying T-shirt: {e}")

        ret, jpeg = cv2.imencode('.jpg', img)
        frame = jpeg.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == "__main__":
    app.run(debug=True)
